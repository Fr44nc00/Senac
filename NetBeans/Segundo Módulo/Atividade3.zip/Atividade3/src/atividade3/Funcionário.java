package atividade3;

public abstract class Funcionário {
   abstract void salario();
   abstract void aumento(double aumento);
   abstract void dados();
}
