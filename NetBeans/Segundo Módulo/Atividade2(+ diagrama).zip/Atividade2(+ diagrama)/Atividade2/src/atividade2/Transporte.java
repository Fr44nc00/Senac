package atividade2;

public class Transporte {
    private String tipo;
    private double valor;
    
    public Transporte(String tipo,double valor){
        this.tipo = tipo;
        this.valor = valor;
    }
    public double getvalor(){
        return valor;
    }
}
