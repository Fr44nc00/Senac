package atividade4;

public interface Impostos {
    void valor();
    void descrever();
}

