package com.senac.exemplothymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemplothymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemplothymeleafApplication.class, args);
	}

}
